----------PLEASE FOLLOW THE INSTRUCTION CAREFULLY-----------------

I have developed these programm using
	OS: Arch Linux
	IDE: Spring Tool Suites, Visual Studio Code
	DATABSE SERVER: MarriaDB-10 (mysql 8 will work fine)
	DATABSE GUI: DBeaver Community Edition (MySQL workbeanch also work fine)
	JAVA: Java-8
	ANGULAR: Angular-12-cli
	NODEJS VERISON: 14.17.3 lts
	NPM VERSION: 6.14.14 lts
	
For Database:
--------------
This is the most important part cause without this the java program will not work properly and you
will not be able to login to angular projects at all.

I used marriadb 10 for database but mysql 8 will work fine but not bellow 8.

I have provided a sql file named ums.sql. This contains all demo data you need.

(N.B: if you do not want to import data from ums.sql file but still want to run the java program.
	No problem, when you run the java jar file this will automatically create all the tables needed
	but you have to configure the database username, password and database name properly {needed also
	for importing data from ums.sql}. follow bellow...)

CAUSION THIS DATABASE CONFIGURATION MUST BE SAME:
 	database username: root
 	databse password: Topu123-=
 	database port: 3006
	database name: ums 

If you want to import given data from ums.sql follow bellow:
	Using cmd/terminal: open cmd/terminal in the same location of ums.sql and run (mysql -u root -p ums < ums.sql)
	Using GUI: please follow the import instruction of MySQL workbeanch or DBaver

For (ums-0.0.1.jar):
--------------------
	1. To run the jar file java 8 must be installed on your system.
	2. If java is installed just run (java -jar ums-0.0.1.jar) this will run the program on 8080.
	3. If the program runs fine that's it. You don't have to do anything else on this side.

For (Angular projects):
------------------------
There are two angular projects named:
	1. ums (for administration and teacher)
	2. ums-student (for students only)
To run these program you need to install http-server globally by running this commang on
cmd/terminal (npm install -global http-server) use sudo if using linux, you can also use npx or brew etc.

	1. run ums(administration and teacher):
		open new cmd/terminal on the same location of ums folder and run command 
			(http-server ums/ -p 4200) this will start http-server on port 4200
		output will be like: 
			Available on:
		  	http://127.0.0.1:4200
		  	http://192.168.0.118:4200
			Hit CTRL-C to stop the server
		(now open browser and type http://127.0.0.1:4200 or localhost:4200)

	2. run ums-student(student-interface):
		open new cmd/terminal on the same location of ums folder and run command 
			(http-server ums-student/ -p 4201) this will start http-server on port 4200
		output will be like: 
			Available on:
		  	http://127.0.0.1:4201
		  	http://192.168.0.118:4201
			Hit CTRL-C to stop the server
		(now open new tab on browser and type http://127.0.0.1:4201 or localhost:4201)

USERNAME and PASSWORD are given on the file ums_user_password.txt

any kind of information or help contact me: topuraihan85@gmail.com

best of luck......

