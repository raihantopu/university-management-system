-- MariaDB dump 10.19  Distrib 10.6.4-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ums
-- ------------------------------------------------------
-- Server version	10.6.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendence`
--

DROP TABLE IF EXISTS `attendence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendence` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attended` bit(1) NOT NULL,
  `date` datetime(6) DEFAULT NULL,
  `registration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class_roll` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exam_roll` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dept_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendence`
--

LOCK TABLES `attendence` WRITE;
/*!40000 ALTER TABLE `attendence` DISABLE KEYS */;
INSERT INTO `attendence` VALUES (52,'','2021-08-31 00:00:00.000000','2014014312','Anamul Haque','Tue Aug 31 2021 00:01:35 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(53,'','2021-08-31 00:00:00.000000','2014014346','Iffat Saki','Tue Aug 31 2021 00:01:35 GMT+0600 (Bangladesh Standard Time)','0009','3238','27th','8th','BA',2),(54,'','2021-08-31 00:00:00.000000','2014014123','Sujan Khan','Tue Aug 31 2021 00:01:35 GMT+0600 (Bangladesh Standard Time)','3234','4233','27th','8th','BA',32),(56,'\0','2021-08-31 00:00:00.000000','2014014317','Md. Topu Riahan','Tue Aug 31 2021 00:01:35 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(57,'','2021-08-31 00:00:00.000000','2014014313','Bashir Hossain','Tue Aug 31 2021 00:01:43 GMT+0600 (Bangladesh Standard Time)','32','asdf','28th','7th','BA',33),(58,'\0','2021-08-31 00:00:00.000000','2014014314','Amzad Khan','Tue Aug 31 2021 00:02:15 GMT+0600 (Bangladesh Standard Time)','31','sdfa','29th','6th','BA',34),(69,'','2021-09-01 00:00:00.000000','2014014312','Anamul Haque','Sat Sep 04 2021 19:35:30 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(70,'','2021-09-01 00:00:00.000000','2014014346','Iffat Saki','Sat Sep 04 2021 19:35:30 GMT+0600 (Bangladesh Standard Time)','0009','3238','27th','8th','BA',2),(71,'\0','2021-09-01 00:00:00.000000','2014014123','Sujan Khan','Sat Sep 04 2021 19:35:30 GMT+0600 (Bangladesh Standard Time)','3234','4233','27th','8th','BA',32),(72,'\0','2021-09-01 00:00:00.000000','2014014315','Raihan Khan','Sat Sep 04 2021 19:35:30 GMT+0600 (Bangladesh Standard Time)','50','3424','27th','8th','BA',34),(73,'','2021-09-01 00:00:00.000000','2014014317','Md. Topu Riahan','Sat Sep 04 2021 19:35:30 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(74,'','2021-09-01 00:00:00.000000','2014014313','Bashir Hossain','Sat Sep 04 2021 19:35:43 GMT+0600 (Bangladesh Standard Time)','32','asdf','28th','7th','BA',32),(75,'','2021-09-01 00:00:00.000000','2014014314','Amzad Khan','Sat Sep 04 2021 19:35:50 GMT+0600 (Bangladesh Standard Time)','31','sdfa','29th','6th','BA',34),(76,'','2021-09-02 00:00:00.000000','2014014312','Anamul Haque','Sat Sep 04 2021 19:36:05 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(77,'','2021-09-02 00:00:00.000000','2014014346','Iffat Saki','Sat Sep 04 2021 19:36:05 GMT+0600 (Bangladesh Standard Time)','0009','3238','27th','8th','BA',2),(78,'','2021-09-02 00:00:00.000000','2014014123','Sujan Khan','Sat Sep 04 2021 19:36:05 GMT+0600 (Bangladesh Standard Time)','3234','4233','27th','8th','BA',32),(79,'','2021-09-02 00:00:00.000000','2014014315','Raihan Khan','Sat Sep 04 2021 19:36:05 GMT+0600 (Bangladesh Standard Time)','50','3424','27th','8th','BA',34),(80,'','2021-09-02 00:00:00.000000','2014014317','Md. Topu Riahan','Sat Sep 04 2021 19:36:05 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(81,'','2021-09-03 00:00:00.000000','2014014312','Anamul Haque','Sat Sep 04 2021 19:36:11 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(82,'\0','2021-09-03 00:00:00.000000','2014014346','Iffat Saki','Sat Sep 04 2021 19:36:11 GMT+0600 (Bangladesh Standard Time)','0009','3238','27th','8th','BA',2),(83,'','2021-09-03 00:00:00.000000','2014014123','Sujan Khan','Sat Sep 04 2021 19:36:11 GMT+0600 (Bangladesh Standard Time)','3234','4233','27th','8th','BA',32),(84,'\0','2021-09-03 00:00:00.000000','2014014315','Raihan Khan','Sat Sep 04 2021 19:36:11 GMT+0600 (Bangladesh Standard Time)','50','3424','27th','8th','BA',34),(85,'','2021-09-03 00:00:00.000000','2014014317','Md. Topu Riahan','Sat Sep 04 2021 19:36:11 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(86,'','2021-09-04 00:00:00.000000','2014014312','Anamul Haque','Sat Sep 04 2021 19:36:19 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(87,'','2021-09-04 00:00:00.000000','2014014346','Iffat Saki','Sat Sep 04 2021 19:36:19 GMT+0600 (Bangladesh Standard Time)','0009','3238','27th','8th','BA',2),(88,'\0','2021-09-04 00:00:00.000000','2014014123','Sujan Khan','Sat Sep 04 2021 19:36:19 GMT+0600 (Bangladesh Standard Time)','3234','4233','27th','8th','BA',32),(89,'\0','2021-09-04 00:00:00.000000','2014014315','Raihan Khan','Sat Sep 04 2021 19:36:19 GMT+0600 (Bangladesh Standard Time)','50','3424','27th','8th','BA',34),(90,'\0','2021-09-04 00:00:00.000000','2014014317','Md. Topu Riahan','Sat Sep 04 2021 19:36:19 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(91,'','2021-09-05 00:00:00.000000','2014014312','Anamul Haque','Sun Sep 05 2021 09:41:14 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(92,'\0','2021-09-05 00:00:00.000000','2014014346','Iffat Saki','Sun Sep 05 2021 09:41:14 GMT+0600 (Bangladesh Standard Time)','0009','3238','27th','8th','BA',2),(93,'\0','2021-09-05 00:00:00.000000','2014014123','Sujan Khan','Sun Sep 05 2021 09:41:14 GMT+0600 (Bangladesh Standard Time)','3234','4233','27th','8th','BA',32),(94,'','2021-09-05 00:00:00.000000','2014014315','Raihan Khan','Sun Sep 05 2021 09:41:14 GMT+0600 (Bangladesh Standard Time)','50','3424','27th','8th','BA',34),(95,'','2021-09-05 00:00:00.000000','2014014317','Md. Topu Riahan','Sun Sep 05 2021 09:41:14 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(96,'','2021-09-08 00:00:00.000000','2014014313','Bashir Hossain','Wed Sep 08 2021 12:06:04 GMT+0600 (Bangladesh Standard Time)','32','asdf','28th','7th','BA',32),(97,'','2021-09-18 00:00:00.000000','2014014312','Anamul Haque','Sat Sep 18 2021 11:17:21 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(98,'\0','2021-09-18 00:00:00.000000','2014014317','Md. Topu Riahan','Sat Sep 18 2021 11:17:21 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(99,'','2021-09-18 00:00:00.000000','2014014312','Anamul Haque','Sat Sep 18 2021 11:49:27 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(100,'','2021-09-18 00:00:00.000000','2014014317','Md. Topu Riahan','Sat Sep 18 2021 11:49:27 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(101,'','2021-09-18 00:00:00.000000','2014014315','Raihan Khan','Sat Sep 18 2021 11:58:26 GMT+0600 (Bangladesh Standard Time)','50','3424','27th','8th','BA',34),(102,'','2021-09-19 00:00:00.000000','2014014312','Anamul Haque','Sun Sep 19 2021 10:27:38 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(103,'\0','2021-09-19 00:00:00.000000','2014014317','Md. Topu Riahan','Sun Sep 19 2021 10:27:38 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33),(104,'','2021-09-19 00:00:00.000000','2014014320','Demo','Sun Sep 19 2021 17:47:38 GMT+0600 (Bangladesh Standard Time)','4565','4545','27th','8th','BA',33),(105,'','2021-09-19 00:00:00.000000','2014014321','Tuhin Hossain','Sun Sep 19 2021 17:47:38 GMT+0600 (Bangladesh Standard Time)','789','565','27th','8th','BA',33),(106,'\0','2021-09-19 00:00:00.000000','2014014323','Azom Khan','Sun Sep 19 2021 17:47:38 GMT+0600 (Bangladesh Standard Time)','455','5454','27th','8th','BA',33),(107,'\0','2021-09-19 00:00:00.000000','2014014312','Anamul Haque','Sun Sep 19 2021 17:47:38 GMT+0600 (Bangladesh Standard Time)','234','34','27th','8th','BA',33),(108,'','2021-09-19 00:00:00.000000','2014014317','Md. Topu Riahan','Sun Sep 19 2021 17:47:38 GMT+0600 (Bangladesh Standard Time)','323','344','27th','8th','BA',33);
/*!40000 ALTER TABLE `attendence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendence_student_mapping`
--

DROP TABLE IF EXISTS `attendence_student_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendence_student_mapping` (
  `attendence_id` bigint(20) NOT NULL,
  `student_student_id` bigint(20) NOT NULL,
  KEY `FK4ugsrqw9iws7x12irrvhpuh0e` (`student_student_id`),
  KEY `FKktv6u8ck38411rejoi5gx22sq` (`attendence_id`),
  CONSTRAINT `FK4ugsrqw9iws7x12irrvhpuh0e` FOREIGN KEY (`student_student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `FKktv6u8ck38411rejoi5gx22sq` FOREIGN KEY (`attendence_id`) REFERENCES `attendence` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendence_student_mapping`
--

LOCK TABLES `attendence_student_mapping` WRITE;
/*!40000 ALTER TABLE `attendence_student_mapping` DISABLE KEYS */;
INSERT INTO `attendence_student_mapping` VALUES (69,104),(70,105),(71,106),(72,109),(73,110),(74,107),(75,108),(76,104),(77,105),(78,106),(79,109),(80,110),(81,104),(82,105),(83,106),(84,109),(85,110),(86,104),(87,105),(88,106),(89,109),(90,110),(91,104),(92,105),(93,106),(94,109),(96,107),(97,104),(98,110),(99,104),(100,110),(101,109),(102,104),(103,110),(104,21),(105,22),(106,23),(107,104),(108,110);
/*!40000 ALTER TABLE `attendence_student_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendence_teacher_mapping`
--

DROP TABLE IF EXISTS `attendence_teacher_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendence_teacher_mapping` (
  `attendence_id` bigint(20) NOT NULL,
  `teachers_teacher_id` bigint(20) NOT NULL,
  KEY `FKlkrqfa9hxeov24v6875yj9w9o` (`teachers_teacher_id`),
  KEY `FK20jofx7q0vg9lfe3o8mklac7t` (`attendence_id`),
  CONSTRAINT `FK20jofx7q0vg9lfe3o8mklac7t` FOREIGN KEY (`attendence_id`) REFERENCES `attendence` (`id`),
  CONSTRAINT `FKlkrqfa9hxeov24v6875yj9w9o` FOREIGN KEY (`teachers_teacher_id`) REFERENCES `teacher` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendence_teacher_mapping`
--

LOCK TABLES `attendence_teacher_mapping` WRITE;
/*!40000 ALTER TABLE `attendence_teacher_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendence_teacher_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch`
--

DROP TABLE IF EXISTS `batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch` (
  `batch_id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `UK_dsqu4au4oosa21d90buiosmeq` (`batch_code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch`
--

LOCK TABLES `batch` WRITE;
/*!40000 ALTER TABLE `batch` DISABLE KEYS */;
INSERT INTO `batch` VALUES (1,'101','27th'),(2,'102','28th'),(3,'103','29th'),(4,'104','30th');
/*!40000 ALTER TABLE `batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department_dept_id` bigint(20) DEFAULT NULL,
  `department_course_fk` bigint(20) DEFAULT NULL,
  `dept_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `FK5vy5grgmbf7tv0w6l5wsxihrr` (`department_dept_id`),
  KEY `FK8absr45rksc2gget0nwxel182` (`department_course_fk`),
  CONSTRAINT `FK5vy5grgmbf7tv0w6l5wsxihrr` FOREIGN KEY (`department_dept_id`) REFERENCES `departments` (`dept_id`),
  CONSTRAINT `FK8absr45rksc2gget0nwxel182` FOREIGN KEY (`department_course_fk`) REFERENCES `departments` (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'202','BISLM theory','BISLM-101','BA','8th',NULL,32,32),(2,'203','BISLM practical','BISLM-102','BA','8th',NULL,32,32),(3,'205','BISLM practical','MISLM-102','MA','2nd',NULL,32,32),(4,'204','BISLM practical','MISLM-101','MA','1st',NULL,32,32),(8,'206','Bangla first course','BANGLA-101','BA','5th',NULL,2,2),(9,'207','Bangla second part for masters.','BANGLA-102','BA','8th',NULL,2,2),(10,'208','English First Part','ENG-101','BA','8th',NULL,33,33),(11,'209','English Second Paper','ENG-102','BA','8th',NULL,33,33),(12,'210','Management first paper','MAN-101','BA','8th',NULL,34,34),(13,'322','Bangla poem for 8th semester','BANGLA-103','BA','8th',NULL,2,2),(14,'211','Bangla for Masters','BANGLA-104','MA','1st',NULL,NULL,2);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `create_faculty_and_institution`
--

DROP TABLE IF EXISTS `create_faculty_and_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `create_faculty_and_institution` (
  `id` bigint(20) NOT NULL,
  `faculty_ins_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faculty_ins_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faculty_inscode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fac_or_ins_facorins_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6bddolylf3nx2bk14l9krcy29` (`faculty_inscode`),
  KEY `FK4upb0n49a1vm2bossbqkux5u1` (`fac_or_ins_facorins_id`),
  CONSTRAINT `FK4upb0n49a1vm2bossbqkux5u1` FOREIGN KEY (`fac_or_ins_facorins_id`) REFERENCES `faculty_or_institution` (`facorins_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `create_faculty_and_institution`
--

LOCK TABLES `create_faculty_and_institution` WRITE;
/*!40000 ALTER TABLE `create_faculty_and_institution` DISABLE KEYS */;
INSERT INTO `create_faculty_and_institution` VALUES (29,'this handles all dept\'s of ARTS Budilding','ARTS','101',26),(30,'this handles all dept\'s of Social Science','SOC_SCIENCE','102',26),(31,'this handles all dept\'s IBA','IBA','103',27);
/*!40000 ALTER TABLE `create_faculty_and_institution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `dept_id` bigint(20) NOT NULL,
  `dept_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dept_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dept_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_fac_and_ins_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `UK_a98yj7l53srcy6e08grm1tw90` (`dept_code`),
  KEY `FKkoushak4iwhgn8pee10asfke4` (`create_fac_and_ins_id`),
  CONSTRAINT `FKkoushak4iwhgn8pee10asfke4` FOREIGN KEY (`create_fac_and_ins_id`) REFERENCES `create_faculty_and_institution` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (2,'104','Bengali Literature','BANGLA',29),(32,'101','The dept. of Information Science And Library Management','Information Science & Library Management',29),(33,'102','English Literature','ENGLISH',29),(34,'103','Dept. of Management IBA','MANAGEMENT',31);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty_or_institution`
--

DROP TABLE IF EXISTS `faculty_or_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty_or_institution` (
  `facorins_id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`facorins_id`),
  UNIQUE KEY `UK_4g0siq14qapyta024uhnnr32y` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty_or_institution`
--

LOCK TABLES `faculty_or_institution` WRITE;
/*!40000 ALTER TABLE `faculty_or_institution` DISABLE KEYS */;
INSERT INTO `faculty_or_institution` VALUES (26,'001-FACULTY','this handles all the faculties','All Faculties'),(27,'002-INSTITIUTION','this handles all the institutions','All Institutions');
/*!40000 ALTER TABLE `faculty_or_institution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hall`
--

DROP TABLE IF EXISTS `hall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hall` (
  `id` bigint(20) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_o4wykvw5p088pkv6ded24uq66` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hall`
--

LOCK TABLES `hall` WRITE;
/*!40000 ALTER TABLE `hall` DISABLE KEYS */;
INSERT INTO `hall` VALUES (6,'102','SS Zahurul Haque Hall'),(7,'103','Bijoy Ekattor'),(112,'101','Jia Hall'),(159,'104','SM Hall');
/*!40000 ALTER TABLE `hall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (24);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `result` (
  `result_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `obtained_result` int(11) NOT NULL,
  `registration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` bit(1) NOT NULL,
  `student_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`result_id`),
  UNIQUE KEY `UK_by0nuwore6cqhogenh0hbwqv` (`result_code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` VALUES (10,75,'2014014317','2014014317_ENG-101','8th','','Md. Topu Riahan','BA','208','ENG-101'),(11,40,'2014014317','2014014317_ENG-102','8th','','Md. Topu Riahan','BA','209','ENG-102'),(12,87,'2014014312','2014014312_ENG-101','8th','','Anamul Haque','BA','208','ENG-101'),(15,95,'2014014312','2014014312_ENG-102','8th','','Anamul Haque','BA','209','ENG-102'),(17,55,'2014014315','2014014315_MAN-101','8th','','Raihan Khan','BA','210','MAN-101'),(18,80,'2014014317','2014014317_8th','8th','','Md. Topu Riahan','BA','209','ENG-102');
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (13,'101','','ROLE_STUDENT'),(15,'102','','ROLE_ADMIN'),(16,'103','\0','ROLE_STAFF');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary`
--

DROP TABLE IF EXISTS `salary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `basic_salary` double NOT NULL,
  `day_of_payment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emp_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `month_of_salary` date DEFAULT NULL,
  `salary_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_salary` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary`
--

LOCK TABLES `salary` WRITE;
/*!40000 ALTER TABLE `salary` DISABLE KEYS */;
INSERT INTO `salary` VALUES (1,1000,'2021-09-10','abc','2021-09-10','bdc',127897),(2,50000,'Sat Sep 18 2021 23:54:05 GMT+0600 (Bangladesh Standard Time)','789','2021-09-17','',20000),(3,0,'Sun Sep 19 2021 00:00:49 GMT+0600 (Bangladesh Standard Time)','101','2021-09-19','101Sun Sep 19 2021 00:00:41 GMT+0600 (Bangladesh Standard Time)',0),(4,50000,'Sun Sep 19 2021 00:01:34 GMT+0600 (Bangladesh Standard Time)','789','2021-09-19','789Sun Sep 19 2021 00:00:41 GMT+0600 (Bangladesh Standard Time)',20000),(5,50000,'Sun Sep 19 2021 00:02:17 GMT+0600 (Bangladesh Standard Time)','789','2021-08-02','789Mon Aug 02 2021 00:00:00 GMT+0600 (Bangladesh Standard Time)',20000),(6,40000,'Sun Sep 19 2021 00:36:08 GMT+0600 (Bangladesh Standard Time)','101','2021-07-01','101Thu Jul 01 2021 00:00:00 GMT+0600 (Bangladesh Standard Time)',16000),(7,40000,'Sun Sep 19 2021 00:36:08 GMT+0600 (Bangladesh Standard Time)','102','2021-07-01','102Thu Jul 01 2021 00:00:00 GMT+0600 (Bangladesh Standard Time)',16000),(8,30000,'Sun Sep 19 2021 10:51:35 GMT+0600 (Bangladesh Standard Time)','103','2021-05-04','103Tue May 04 2021 00:00:00 GMT+0600 (Bangladesh Standard Time)',12000),(9,40000,'Sun Sep 19 2021 10:52:03 GMT+0600 (Bangladesh Standard Time)','101','2021-01-06','101Wed Jan 06 2021 00:00:00 GMT+0600 (Bangladesh Standard Time)',16000),(10,40000,'Sun Sep 19 2021 10:52:03 GMT+0600 (Bangladesh Standard Time)','102','2021-01-06','102Wed Jan 06 2021 00:00:00 GMT+0600 (Bangladesh Standard Time)',16000),(11,50000,'Sun Sep 19 2021 17:58:06 GMT+0600 (Bangladesh Standard Time)','789','2021-09-19','789Sun Sep 19 2021 17:57:54 GMT+0600 (Bangladesh Standard Time)',20000),(12,40000,'Sun Sep 19 2021 17:58:27 GMT+0600 (Bangladesh Standard Time)','101','2021-09-19','101Sun Sep 19 2021 17:57:54 GMT+0600 (Bangladesh Standard Time)',16000),(13,40000,'Sun Sep 19 2021 17:58:27 GMT+0600 (Bangladesh Standard Time)','102','2021-09-19','102Sun Sep 19 2021 17:57:54 GMT+0600 (Bangladesh Standard Time)',16000);
/*!40000 ALTER TABLE `salary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_questions`
--

DROP TABLE IF EXISTS `security_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_questions` (
  `sec_que_id` int(11) NOT NULL AUTO_INCREMENT,
  `sec_que` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sec_que_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`sec_que_id`),
  UNIQUE KEY `UK_k9rt4b7b6b3ko5skm9yndsc7x` (`sec_que_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_questions`
--

LOCK TABLES `security_questions` WRITE;
/*!40000 ALTER TABLE `security_questions` DISABLE KEYS */;
INSERT INTO `security_questions` VALUES (1,'What is your pet name?','101'),(2,'What is your nick name?','102'),(3,'What is your childhood friend name?','103');
/*!40000 ALTER TABLE `security_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `session_id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `UK_vtfeuhsf3ffd7dasm266poqi` (`session_code`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (1,'2014-15','101'),(2,'2015-16','102'),(3,'2016-17','103'),(4,'2017-18','104'),(5,'2018-19','105'),(16,'2019-20','106');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` bigint(20) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageurl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanant_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_9iyphxhcq6d836q8vrykuw6vx` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (3,'789','Senior Officer','bashir@gmail.com','','1st','/home/Picture/topu.jpg','Bashir Hossain','Dhaka','Dhaka');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_course`
--

DROP TABLE IF EXISTS `student_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_course` (
  `student_id` bigint(20) NOT NULL,
  `course_id` bigint(20) NOT NULL,
  PRIMARY KEY (`student_id`,`course_id`),
  KEY `FKejrkh4gv8iqgmspsanaji90ws` (`course_id`),
  CONSTRAINT `FKejrkh4gv8iqgmspsanaji90ws` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  CONSTRAINT `FKnh5bqghcqt8f5p2yqshbr5g6q` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_course`
--

LOCK TABLES `student_course` WRITE;
/*!40000 ALTER TABLE `student_course` DISABLE KEYS */;
INSERT INTO `student_course` VALUES (105,13),(106,1),(106,2),(107,3),(107,4),(110,10),(110,11),(111,8),(111,9);
/*!40000 ALTER TABLE `student_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_fees`
--

DROP TABLE IF EXISTS `student_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_fees` (
  `fees_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `activity_fee` double NOT NULL,
  `addmission_fee` double NOT NULL,
  `dept_id` bigint(20) NOT NULL,
  `exam_fee` double NOT NULL,
  `fees_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lab_fee` double NOT NULL,
  `library_fee` double NOT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester_fee` double NOT NULL,
  `seminar_fee` double NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fees_id`),
  UNIQUE KEY `UK_9sikcdcftmpv3m18u69tg2ihj` (`fees_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_fees`
--

LOCK TABLES `student_fees` WRITE;
/*!40000 ALTER TABLE `student_fees` DISABLE KEYS */;
INSERT INTO `student_fees` VALUES (1,200,1000,32,500,'102',200,100,'1st',500,100,'BA'),(2,100,1000,32,500,'103',200,100,'2nd',500,100,'BA'),(3,200,1500,32,800,'104',200,150,'1st',700,150,'MA'),(8,100,1500,32,200,'105',200,150,'8th',500,300,'BA'),(9,100,1500,34,500,'106',200,150,'8th',700,250,'BA'),(10,200,2000,33,500,'107',200,200,'8th',500,300,'BA');
/*!40000 ALTER TABLE `student_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_paid_fees`
--

DROP TABLE IF EXISTS `student_paid_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_paid_fees` (
  `paid_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `activity_fee` double NOT NULL,
  `addmission_fee` double NOT NULL,
  `dept_id` bigint(20) NOT NULL,
  `exam_fee` double NOT NULL,
  `lab_fee` double NOT NULL,
  `library_fee` double NOT NULL,
  `paid_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paid_status` bit(1) NOT NULL,
  `registration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester_fee` double NOT NULL,
  `seminar_fee` double NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`paid_id`),
  UNIQUE KEY `UK_ihkbt0au373ko0ux4ha18eow` (`paid_code`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_paid_fees`
--

LOCK TABLES `student_paid_fees` WRITE;
/*!40000 ALTER TABLE `student_paid_fees` DISABLE KEYS */;
INSERT INTO `student_paid_fees` VALUES (13,50,500,32,50,50,50,'jp8fZFnR','','2014014123','8th',505,305,'BA'),(14,50,1200,34,300,100,100,'Jz5QzAeq','\0','2014014315','8th',500,100,'BA'),(15,0,0,33,0,0,0,'VO6KpGe8','\0','2014014312','8th',0,0,'BA'),(16,200,2000,33,500,200,200,'kVu1iMSg','','2014014317','8th',500,300,'BA'),(21,0,0,33,0,0,0,'2txduQ3g','\0','2014014345','5th',0,0,'BA'),(22,0,0,33,0,0,0,'xsuBvWYv','\0','2014014320','8th',0,0,'BA'),(23,0,0,33,0,0,0,'wqUw7uCw','\0','2014014321','8th',0,0,'BA'),(24,0,0,33,0,0,0,'LWftjnbA','\0','2014014323','8th',0,0,'BA'),(25,0,0,33,0,0,0,'EwDo2mLu','\0','2014014312','8th',0,0,'BA'),(27,0,0,33,0,0,0,'2JocWzWg','\0','2014014320','8th',0,0,'BA'),(28,0,0,33,0,0,0,'epUJEXav','\0','2014014321','8th',0,0,'BA'),(29,0,0,33,0,0,0,'kVLPIQtD','\0','2014014323','8th',0,0,'BA'),(30,0,0,33,0,0,0,'GN3udAKp','\0','2014014312','8th',0,0,'BA');
/*!40000 ALTER TABLE `student_paid_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `student_id` bigint(20) NOT NULL,
  `batch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class_roll` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exam_roll` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hall_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageurl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `local_guardian_cell` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_cell` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanent_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personal_cell` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dept_id` bigint(20) DEFAULT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `UK_5ukt3bsqef28jwkfl6ti1pg6u` (`registration`),
  KEY `FKi1trtove3brbpybgyeepb06nf` (`dept_id`),
  CONSTRAINT `FKi1trtove3brbpybgyeepb06nf` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (21,'27th','2021-09-01','4565','demo@gmail.com','4545','ABCD','male','JKL','SS Zahurul Haque Hall','./assets/images/2014014320.jpg','465465465465','EFG','456578465','flksdjflksjdlfk','01748117651','ulkfjsldkjflk','2014014320','2014-15','Demo',33,'8th','BA'),(22,'27th','2021-09-13','789','tuhin@gmail.com','565','Not Known','male','Not Known','SS Zahurul Haque Hall','./assets/images/2014014321.jpg','5646546565','Not Known','4565465464','fjlskjflksdl','4646465465465','jflksjflkj','2014014321','2014-15','Tuhin Hossain',33,'8th','BA'),(23,'27th','2021-09-21','455','azom@gmail.com','5454','Not Knwn','male','Not Known','SS Zahurul Haque Hall','./assets/images/2014014323.jpg','46564646555','Not Known','4656546546','hkjfshkdjfhksjd','56564656','ulhfkjsdfhkj','2014014323','2014-15','Azom Khan',33,'8th','BA'),(104,'27th','2006-06-12','234','anamul@gmail.com','34','N/A','female','N/A','Jia Hall','./assets/images/2014014312.jpg','4234234234','N/A','4534534','asdf','5646465','Dhaka','2014014312','2016-17','Anamul Haque',33,'8th','BA'),(105,'27th','2021-08-12','0009','iffatsaki@gmail.com','3238','Tofazzol Haque','female','Tofazzol Haque','SS Zahurul Haque Hall','./assets/images/2014014346.jpg','01928652489','Rubina Begum','01928652489','Anupompor, Charghat, Rajshahi, Bangladesh','01748117651','Room No. 276, SS Zahurul Haque Hall, University of Dhaka','2014014346','2015-16','Iffat Saki',2,'8th','BA'),(106,'27th','2021-08-05','3234','sujan@sujan.com','4233','wer','male','wer','SS Zahurul Haque Hall','./assets/images/2014014123.jpg','234234234','wer','234234234','Dhaka','4234234234','Dhaka','2014014123','2014-15','Sujan Khan',32,'8th','BA'),(107,'28th','2021-08-16','32','bashir.rusulpur@gmail.com','asdf','werwer','male','fasdf','Jia Hall','./assets/images/2014014313.jpg',NULL,'erwer','dfasdf','dhaka','fdasdf','dhaka','2014014313','2014-15','Bashir Hossain',32,'7th','MA'),(108,'29th','2021-08-27','31','amzad@gmail.com','2010','MR. ABC','male','MR. ABC','SS Zahurul Haque Hall','./assets/images/2014014314.jpg','4564545454','MRS. ABC','1054658782','Kustia','0174124587','Dhaka','2014014314','2017-18','Amzad Khan',34,'6th','BA'),(109,'27th','2021-08-24','50','raihan@gmail.com','3424','Tofazzol Haque','male','Tofazzol Haque','Jia Hall','./assets/images/2014014315.jpg','','Rubina Begum','','Anupompur, Charghat, Rajshahi, Bangladesh','fdsf','Room No. 276, Shahid Searjeant Zahurul Haque Hall, University of Dhaka','2014014315','2015-16','Raihan Khan',34,'8th','BA'),(110,'27th','2021-08-04','323','topuraihan85@gmail.com','344','jdlk','male','flksdj','Bijoy Ekattor','./assets/images/2014014317.jpg','jflkdjs','flkdsj','0903','fsdkfjl','fkjlskd','fsdkjf','2014014317','2014-15','Md. Topu Riahan',33,'8th','BA'),(111,'30th','2021-08-17','50','sakisaki@saki.com','23423','Tofazzol Haque','female','','SS Zahurul Haque Hall','./assets/images/2014014345.jpg','5464556655','jhgghghjgjh','4546546555','','0144654654','','2014014345','2016-17','Saki Saki',33,'5th','BA');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher` (
  `teacher_id` bigint(20) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageurl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanant_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dept_dept_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`teacher_id`),
  UNIQUE KEY `UK_fbgbhsfeo9ix0av57dg8vppw0` (`code`),
  KEY `FK2b4ju7lvegia5odn4hgcxupmv` (`dept_dept_id`),
  CONSTRAINT `FK2b4ju7lvegia5odn4hgcxupmv` FOREIGN KEY (`dept_dept_id`) REFERENCES `departments` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher`
--

LOCK TABLES `teacher` WRITE;
/*!40000 ALTER TABLE `teacher` DISABLE KEYS */;
INSERT INTO `teacher` VALUES (11,'101','Assistant Proffesor','topu@gmail.com','','2nd','./assets/images/faculty/101.jpg','Md. Topu Raihan','dhaka','Dhaka',32),(12,'102','Assistant Proffesor','atik@gmail.com','','2nd','./assets/images/faculty/102.jpg','Md. Atikuzzaman Lingkon','dhaka','Dhaka',33),(13,'103','Lecturer','bashir@gmail.com','','4th','./assets/images/faculty/103.jpg','Md. Bashir Hossain','dhaka','Dhaka',33),(14,'104','Jonior Lecturer','raihan@gmail.com','','5th','./assets/images/faculty/104.jpg','Md. Raihan Khan','Dhaka','Dhaka',34);
/*!40000 ALTER TABLE `teacher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_course`
--

DROP TABLE IF EXISTS `teacher_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_course` (
  `teacher_id` bigint(20) NOT NULL,
  `course_id` bigint(20) NOT NULL,
  PRIMARY KEY (`teacher_id`,`course_id`),
  KEY `FKp8bco6842vkqh13y4759ib7tk` (`course_id`),
  CONSTRAINT `FKaleldsg7yww5as540ld8iwghe` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`),
  CONSTRAINT `FKp8bco6842vkqh13y4759ib7tk` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_course`
--

LOCK TABLES `teacher_course` WRITE;
/*!40000 ALTER TABLE `teacher_course` DISABLE KEYS */;
INSERT INTO `teacher_course` VALUES (12,9),(12,10),(12,11);
/*!40000 ALTER TABLE `teacher_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `authorities` tinyblob DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` bit(1) NOT NULL,
  `is_not_locked` bit(1) NOT NULL,
  `join_date` datetime(6) DEFAULT NULL,
  `last_login_date` datetime(6) DEFAULT NULL,
  `last_login_date_display` datetime(6) DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageurl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'��\0ur\0[Ljava.lang.String;��V��{G\0\0xp\0\0\0t\0	user:readt\0user:createt\0user:updatet\0user:delete','topuraihan85@gmail.com','Topu','','','2021-08-23 23:03:41.000000','2021-09-19 17:53:50.000000','2021-09-19 13:38:50.000000','Raihan','$2a$10$uJjxCo12l5vbKOJf0j7uXO8xqHjs7W62B.Ma.ie8eU5KTFuPuOA96','ROLE_SUPER_ADMIN','8954278417','topu','./assets/images/users/topu.jpg'),(8,'��\0ur\0[Ljava.lang.String;��V��{G\0\0xp\0\0\0t\0	user:read','bashir.rasulpur@gmail.com','Bashir','','','2021-09-05 10:41:54.000000',NULL,NULL,'Hossain','$2a$10$W9iPU6PV9Nxrdl8FCrpXkORTVRpv9al2C6CHHnDwgItDQKNCt6hpC','ROLE_USER','7014401860','bashir','./assets/images/users/bashir.jpg'),(11,'��\0ur\0[Ljava.lang.String;��V��{G\0\0xp\0\0\0t\0	user:readt\0user:attendence','atik@gmail.com','Md.','','','2021-09-08 10:12:53.000000','2021-09-19 17:11:46.000000','2021-09-19 13:26:33.000000','Atikuzzaman','$2a$10$dr7l.taSYbPTWO9HFLTujeo7SaNcDr/DF/0X0cN4YE51EnAE0X4bm','ROLE_TEACHER','9509082669','atik','./assets/images/users/atik.jpg');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-27  8:50:13
